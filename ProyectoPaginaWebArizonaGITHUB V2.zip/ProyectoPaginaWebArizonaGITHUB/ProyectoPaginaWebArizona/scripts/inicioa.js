// ===========================
// Animación de inicio al cargar la página
// ===========================
window.addEventListener("load", () => {
  // Oculta el loader al cargar la página
  const loader = document.getElementById("loader");
  if (loader) loader.style.display = "none";

  setTimeout(() => {
    // ===========================
    // Crear paneles negros animados
    // ===========================
    const left = document.createElement("div");
    const right = document.createElement("div");
    left.classList.add("split-left");
    right.classList.add("split-right");
    document.body.appendChild(left);
    document.body.appendChild(right);

    // ===========================
    // Oculta el logo y el fondo de intro
    // ===========================
    setTimeout(() => {
      const intro = document.getElementById("intro");
      if (intro) intro.style.display = "none";

      // Abre los paneles (animación)
      left.style.transform = "translateX(-100vw)";
      right.style.transform = "translateX(100vw)";
    }, 2200);

    // ===========================
    // Muestra el contenido principal con animación
    // ===========================
    setTimeout(() => {
      const contenido = document.getElementById("contenido");
      if (contenido) contenido.classList.add("visible");

      // Mostrar la sección de misión/visión/valores con animación lenta
      const empresaInfo = document.getElementById("empresa-info");
      if (empresaInfo) {
        empresaInfo.setAttribute("data-aos", "fade-up");
        empresaInfo.setAttribute("data-aos-duration", "1800");
        empresaInfo.setAttribute("data-aos-delay", "800");
        empresaInfo.classList.add("aos-animate");
      }

      if (left && left.parentNode) left.remove();
      if (right && right.parentNode) right.remove();
    }, 3200); // Aparece después de la animación de intro y paneles
  }, 100);
});

window.addEventListener("DOMContentLoaded", () => {
  // Al cargar, haz visible el header (estado inicial)
  const header = document.querySelector(".main-header");
  if (header) header.style.opacity = "0.7"; // Un poco visible al inicio
});

// ===========================
// Header dinámico al hacer scroll y énfasis en info-blocks
// ===========================
window.addEventListener("scroll", () => {
  const header = document.querySelector(".main-header");
  if (!header) return;

  if (window.scrollY > 50) {
    header.classList.add("header-small");
    header.style.opacity = "1";
  } else {
    header.classList.remove("header-small");
    header.style.opacity = "0.7";
  }

  // Efecto de énfasis en bloques de misión/visión/valores
  document.querySelectorAll('.info-section.info-top .info-block').forEach(block => {
    const rect = block.getBoundingClientRect();
    const inView =
      rect.top < window.innerHeight * 0.7 &&
      rect.bottom > window.innerHeight * 0.2;
    block.classList.toggle('enfasis', inView);
  });

  // Oculta la hero-section al hacer scroll
  const hero = document.querySelector(".hero-section");
  if (hero) {
    if (window.scrollY > 60) {
      hero.classList.add("hide-hero");
    } else {
      hero.classList.remove("hide-hero");
    }
  }
});
