// ===========================
// Animación de inicio al cargar la página
// ===========================
window.addEventListener("load", () => {
  setTimeout(() => {
    // ===========================
    // Crear paneles negros animados
    // ===========================
    const left = document.createElement("div");
    const right = document.createElement("div");
    left.classList.add("split-left");
    right.classList.add("split-right");
    document.body.appendChild(left);
    document.body.appendChild(right);

    // ===========================
    // Oculta el logo y el fondo de intro
    // ===========================
    setTimeout(() => {
      const intro = document.getElementById("intro");
      if (intro) intro.style.display = "none";

      // Abre los paneles (animación)
      left.style.transform = "translateX(-100vw)";
      right.style.transform = "translateX(100vw)";
    }, 2200);

    // ===========================
    // Muestra el contenido principal con animación
    // ===========================
    setTimeout(() => {
      const contenido = document.getElementById("contenido");
      if (contenido) contenido.classList.add("visible");

      if (left && left.parentNode) left.remove();
      if (right && right.parentNode) right.remove();
    }, 3200);
  }, 100);
});

// ===========================
// Header dinámico al hacer scroll y énfasis en info-blocks
// ===========================
window.addEventListener("scroll", () => {
  const header = document.querySelector("header");
  if (header) {
    if (window.scrollY > 40) {
      header.classList.add("header-small");
    } else {
      header.classList.remove("header-small");
    }
  }

  // Efecto de énfasis en bloques de misión/visión/valores
  document.querySelectorAll('.info-section.info-top .info-block').forEach(block => {
    const rect = block.getBoundingClientRect();
    const inView =
      rect.top < window.innerHeight * 0.7 &&
      rect.bottom > window.innerHeight * 0.2;
    block.classList.toggle('enfasis', inView);
  });

  // Oculta la hero-section al hacer scroll
  const hero = document.querySelector(".hero-section");
  if (hero) {
    if (window.scrollY > 60) {
      hero.classList.add("hide-hero");
    } else {
      hero.classList.remove("hide-hero");
    }
  }
});
