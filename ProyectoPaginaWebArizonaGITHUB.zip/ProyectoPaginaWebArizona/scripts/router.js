document.querySelectorAll("#sidebar nav a").forEach(link => {
  link.addEventListener("click", e => {
    e.preventDefault();
    // Quitar clase activa de todos los enlaces
    document.querySelectorAll("#sidebar nav a").forEach(a => a.classList.remove("active"));
    // Agregar clase activa al enlace clickeado
    link.classList.add("active");
    const page = link.getAttribute("data-page");
    fetch(`${page}.html`)
      .then(res => res.text())
      .then(html => {
        document.getElementById("contenido-principal").innerHTML = html;
      });
  });
});
